# -*- encoding:utf-8 -*-_
_author__ = 'n3314'

from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import Qt
import ctypes
dll = ur".\fdlib.dll"
fddll = ctypes.cdll.LoadLibrary(dll)

class RECT(ctypes.Structure):
    _fields_ = (("top", ctypes.c_int),
        ("left", ctypes.c_int),
        ("right", ctypes.c_int),
        ("bottom", ctypes.c_int))

class FaceDetect(QtCore.QObject):
    sigDetect = QtCore.pyqtSignal(list)
    sigGetImage = QtCore.pyqtSignal(QtGui.QImage)
    def __init__(self, parent=None):
        QtCore.QObject.__init__(self, parent)
        self.buffer = None
        self.sigGetImage.connect(self.fd, QtCore.Qt.QueuedConnection)

    @QtCore.pyqtSlot(QtGui.QImage)
    def fd(self, image):
        print 'fd', int(QtCore.QThread.currentThreadId())
        w, h = image.width(), image.height()
        if not self.buffer:
            bufferType = ctypes.c_ubyte * (w * h)
            self.buffer = bufferType()
        buffer = self.buffer
        i = 0
        bits = image.bits()
        address = int(bits)
        for i in range(w * h):
            pixel = ctypes.c_int.from_address(address)
            color = QtGui.QColor(pixel.value)
            buffer[i] = ctypes.c_ubyte(color.lightness())
            address += 4

        fddll.fdlib_detectfaces(ctypes.byref(buffer), w, h, 0)
        n = fddll.fdlib_getndetections()
        res = []
        x, y, w = ctypes.c_int(), ctypes.c_int(), ctypes.c_int()
        for i in range(n):
            fddll.fdlib_getdetection(i, ctypes.byref(x), ctypes.byref(y), ctypes.byref(w))
            res.append((x.value, y.value, w.value, w.value))
        print n, res
        if n:
            self.sigDetect.emit(res)

class MainWindow(QtGui.QWidget):
    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.setWindowFlags(Qt.Window)
        # self.setAttribute(Qt.WA_TranslucentBackground)
        self.rect = None
        self.rectList = None
        self.rectList = []
        self.count = 0
        self.resize(800, 700)
        self.flashImage = QtGui.QImage()
        self.timer = QtCore.QTimer()
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.capture)

        self.fdThread = QtCore.QThread()
        self.fd = FaceDetect()
        self.fd.moveToThread(self.fdThread)
        self.fd.sigDetect.connect(self.onDetect, QtCore.Qt.QueuedConnection)
        self.fdThread.start()

    def onDetect(self, res):
        self.rectList = res

    def paintEvent(self, event):
        if not self.flashImage.isNull():
            painter = QtGui.QPainter(self)
            rect = QtCore.QRectF(0,0,self.flashImage.width(),self.flashImage.height())
            painter.drawImage(rect, self.flashImage)

        for i in self.rectList:
            (x, y, w, h) = i
            rc = QtCore.QRect(x - w / 2, y - h / 2, w, h)
            painter.drawRoundRect(rc)

    def startCapture(self, windId):
        self.captureWndId = windId
        self.timer.start()

    def capture(self):
        hWnd = self.captureWndId
        rcWnd = RECT(0,0,0,0)
        ctypes.windll.user32.GetClientRect(hWnd, ctypes.byref(rcWnd))
        width = rcWnd.right - rcWnd.left
        heigh = rcWnd.bottom - rcWnd.top
        if width <= 0 or heigh <= 0:
            return
        gdi = ctypes.windll.gdi32
        targetDC = ctypes.windll.user32.GetDC(hWnd)
        bitmapDC = gdi.CreateCompatibleDC(targetDC)
        hBitmap = gdi.CreateCompatibleBitmap(targetDC,width,heigh)
        oldBitmap = gdi.SelectObject(bitmapDC, hBitmap)
        gdi.BitBlt(bitmapDC, 0, 0, width, heigh, targetDC, 0, 0, 0x00CC0020)
        self.makeFrame(hBitmap, width*width*4, width, heigh)
        gdi.SelectObject(bitmapDC, oldBitmap)
        gdi.DeleteDC(bitmapDC)
        gdi.DeleteObject(hBitmap)
        ctypes.windll.user32.ReleaseDC(hWnd, targetDC)

    def makeFrame(self, hbitmap, bitSize, width, heigh):
        if width != self.flashImage.width() or heigh != self.flashImage.height():
                 self.flashImage = QtGui.QImage(width, heigh, QtGui.QImage.Format_ARGB32)

        gdi = ctypes.windll.gdi32
        pBits = self.flashImage.bits()
        gdi.GetBitmapBits(hbitmap, bitSize, int(pBits))
        self.count = self.count + 1
        if self.count >= 12:
            self.count = 0
            self.fd.sigGetImage.emit(self.flashImage)
            #res = fd(self.flashImage)
            #self.addRectList(res)
        print 'makeframe', int(QtCore.QThread.currentThreadId())

        self.update()

    def addRectList(self, l):
        self.rectList = l

if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    w = MainWindow()
    w.setWindowTitle(u"测试HelloWorld")
    w.show()
    w.startCapture(0x00011676)
    sys.exit(app.exec_())
