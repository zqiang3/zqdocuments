#include "Python.h"

static PyObject *reverse(PyObject *self, PyObject *args)
{
	const char *str;
	int size;
	char *reverseStr = NULL;
	PyObject *res = NULL;
	if (!PyArg_ParseTuple(args, "s#", &str, &size))
		return NULL;
	reverseStr = (char*)malloc(size);
	for (int i = 0; i < size; i++){
		reverseStr[i] = str[size - i - 1];
	}
	res = Py_BuildValue("s#", reverseStr, size);
	free(reverseStr);
	return res;
}

static PyMethodDef ReverseMethods[] = {
	{"reverse",  reverse, METH_VARARGS, "revert a string"},
	{NULL, NULL, 0, NULL}        /* Sentinel */
};

PyMODINIT_FUNC
initsimple(void)
{
	PyObject *m;

	m = Py_InitModule("simple", ReverseMethods);
	if (m == NULL)
		return;
}
