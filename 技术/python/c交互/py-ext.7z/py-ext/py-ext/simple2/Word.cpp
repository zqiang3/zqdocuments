#include "Word.h"
#include "string.h"


Word::Word(const char *w)
{
	int size = strlen(w);
	the_word = new char[size];
	for (int i = 0; i < size; i++){
		the_word[i] = w[size - i - 1];
	}
}

char *Word::reverse() const
{
	return the_word;
}

Word::~Word(void)
{
}
