#pragma once
class __declspec(dllexport) Word
{
public:
	Word(const char *w);
	~Word(void);

	char *reverse() const;

private:
	char *the_word;
};

