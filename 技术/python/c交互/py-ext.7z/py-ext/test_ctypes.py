#-*- coding: utf-8 -*-
__author__ = 'g2127'

from PyQt4 import QtCore, QtGui
from ctypes import *

def py_cmp_func(a, b):
    print "py_cmp_func", a[0], b[0]
    return a[0] - b[0]

def test_1():
    s = create_unicode_buffer(300)
    t = windll.kernel32.GetModuleFileNameW(None, byref(s), 300)
    print s.value


def test_callback():
    libc = cdll.msvcrt
    libc.printf("hihihi")

    IntArray5 = c_int * 5
    ia = IntArray5(5, 1, 7, 33, 99)
    qsort = libc.qsort
    qsort.restype = None

    CMPFUNC = CFUNCTYPE(c_int, POINTER(c_int), POINTER(c_int))
    cmp_func = CMPFUNC(py_cmp_func)

    qsort(ia, len(ia), sizeof(c_int), cmp_func)

    for i in ia: print i,





if __name__ == "__main__":
    #test_1()
    test_callback()

